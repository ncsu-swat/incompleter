#Source: https://stackoverflow.com/questions/56731528/python-threading-typeerror-testmethod-takes-2-positional-arguments-but-12-w
self.T = Thread(target=self._testmethod, args=(arg))