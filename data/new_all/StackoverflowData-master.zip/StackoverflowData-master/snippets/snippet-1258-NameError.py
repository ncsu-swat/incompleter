#Source: https://stackoverflow.com/questions/61823343/typeerror-python-ask-to-insert-self-argument
debugger.status(debugger, True)
debugger()
debugger.log(debugger, 'Test from debugger')