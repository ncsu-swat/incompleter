#Source: https://stackoverflow.com/questions/51939834/random-shufflerange10-report-typeerror
In [20]: num_arr = list(range(10))
In [22]: random.shuffle(num_arr)
In [23]: print(num_arr)
[8, 0, 7, 3, 9, 4, 1, 2, 6, 5]