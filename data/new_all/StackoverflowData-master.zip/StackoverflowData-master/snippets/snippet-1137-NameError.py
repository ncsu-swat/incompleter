#Source: https://stackoverflow.com/questions/72010825/python-attributeerror-module-os-has-no-attribute-exit
os.exit()