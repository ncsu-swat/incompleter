#Source: https://stackoverflow.com/questions/52242859/file-e-python-lib-re-py-line-229-in-finditer-return-compilepattern-flags
from skimage.feature import greycomatrix 