#Source: https://stackoverflow.com/questions/56406492/attributeerror-module-datetime-has-no-attribute-today-error-while-executing
from selenium import webdriver as wd

driver = wd.Firefox(executable_path=r'C:\Users\User\Downloads\geckodriver-v0.24.0-win64')
driver.get('https://youtube.com')