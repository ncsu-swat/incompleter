#Source: https://stackoverflow.com/questions/67099584/attributeerror-module-speedtest-has-no-attribute-speedtest
import speedtest

r = speedtest.Speedtest()