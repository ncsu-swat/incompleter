#Source: https://stackoverflow.com/questions/34750151/nameerror-name-post-is-not-defined
admin.site.register(Post)