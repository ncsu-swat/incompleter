#Source: https://stackoverflow.com/questions/54894588/attributeerror-dataframeiterator-object-has-no-attribute-ndim
predictions = classifier.predict(test_set, batch_size = 64)