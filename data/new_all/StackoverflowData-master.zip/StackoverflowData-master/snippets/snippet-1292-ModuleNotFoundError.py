#Source: https://stackoverflow.com/questions/55113041/attributeerror-module-flask-app-has-no-attribute-route
from xyzapp.autocomplete import autocomplete