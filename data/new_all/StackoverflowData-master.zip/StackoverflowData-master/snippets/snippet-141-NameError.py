#Source: https://stackoverflow.com/questions/40388792/how-to-decode-a-numpy-array-of-encoded-literals-strings-in-python3-attributeerr
import numpy as np
print(array1)
(b'first_element', b'element',...)