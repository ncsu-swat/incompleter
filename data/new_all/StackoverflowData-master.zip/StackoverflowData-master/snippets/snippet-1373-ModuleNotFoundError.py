#Source: https://stackoverflow.com/questions/68342294/what-is-the-cause-of-this-attribute-error
import temp
temp.func()