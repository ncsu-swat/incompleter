#Source: https://stackoverflow.com/questions/72045796/django-get-typeerror-the-json-object-must-be-str-bytes-or-bytearray-not-dict
business_id = models.CharField(unique=True, max_length=100)