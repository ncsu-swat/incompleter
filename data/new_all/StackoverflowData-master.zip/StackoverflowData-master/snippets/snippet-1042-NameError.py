#Source: https://stackoverflow.com/questions/23769732/python-pygame-colours-are-no-tuples-unhashable-type-error-when-used-as-dictiona
clr = str(tilemap.get_at((x, y)))