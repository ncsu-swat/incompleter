#Source: https://stackoverflow.com/questions/72510817/typeerror-descriptor-isoformat-for-datetime-date-objects-doesnt-apply-to-a
dt = date.isoformat(info["start_date"])