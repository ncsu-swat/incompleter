#Source: https://stackoverflow.com/questions/21609227/python-3-3-3-typeerror-list-indices-must-be-integers-not-float
tempBlock = Block(x*64, y*64)
# add block to both and self.levelStructure
self.levelStructure[x][y] = tempBlock