#Source: https://stackoverflow.com/questions/68342294/what-is-the-cause-of-this-attribute-error
import get
get.call_get()