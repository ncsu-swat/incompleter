#Source: https://stackoverflow.com/questions/51972716/python-error-attributeerror-str-object-has-no-attribute-k
s="ABC"

for k in ["isalnum()", "isalpha()", "isdigit()", "islower()", "isupper()"]:
    for c in s:
        print(c.k)