#Source: https://stackoverflow.com/questions/49868472/gmap-draw-typeerror-must-be-real-number-not-str
lat_lon.dtypes