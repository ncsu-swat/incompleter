#Source: https://stackoverflow.com/questions/53522130/python-numpy-error-typeerror-numpy-float64-object-cannot-be-interpreted-as-a
samples = np.append(np.zeros(np.floor(int(frameSize/2.0))), sig)