#Source: https://stackoverflow.com/questions/29618165/why-is-the-order-of-types-in-python-2-fixed-and-an-unorderable-typeerror-in-pyt
object > type > tuple > (bytes or str) > frozenset > set > dict \
       > long > list > int > float > complex > bytearray > None

True