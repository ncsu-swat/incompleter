#Source: https://stackoverflow.com/questions/38044773/receiving-typeerror-object-new-takes-no-parameters-when-new-not-chang
from Windows import MainWindow
game = MainWindow()