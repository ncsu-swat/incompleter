#Source: https://stackoverflow.com/questions/53812466/attributeerror-nonetype-object-has-no-attribute-lower-in-python
locality_address= df_fatch_ID_Address['Col_1_add'].values.tolist()

print (locality_address)