#Source: https://stackoverflow.com/questions/47204175/lane-departure-warning-system-for-autonomous-driving-typeerror-expected-non-em
raise TypeError("expected non-empty vector for x")