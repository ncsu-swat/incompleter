#Source: https://stackoverflow.com/questions/42899389/typeerror-the-json-object-must-be-str-not-dict
{
    "Value1": "SomeValue",
    "data": {
        "subval1": false,
        "subval2": "0a4",
        "subval3": "",
        "subval4": "Click h!",
        "subval5": "1002",
        "subval6": "932",
        "subval7": "i2",
        "subval8": 250,
        "subval9": 0,
        "subval10": 1,
        "subval11": 3,
        "subval12": 1,
        "subval13": "<!>",
        "subval14": "",
        "subval15": "Click !!",
        "subval16": "",
        "subval17": 300
    },
    "error": true,
    "message": "Success",
    "status": 200
}