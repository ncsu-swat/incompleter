#Source: https://stackoverflow.com/questions/66242607/attributeerror-on-tkinter-project
import tkinter
win = tkinter.Tk()
win.title('GUI')
win.mainloop()