#Source: https://stackoverflow.com/questions/54962989/attributeerror-turtle-object-has-no-attribute-addshape
# Snake head
head = turtle.Turtle()                      # create an instance of the class turtle called 'head'
head.speed(0)                               # call the speed method
head.shape("square")                        # defines the shape of the snakes head
head.color("black")                         # defines the colour of the snakes head
head.penup()                                # stop the snake from drawing when moving
head.goto(0,0)                              # moves the snakes head to the coordinates 0,0 on the screen.
head.direction = "stop"                     # stops the turtles head from moving strait away