#Source: https://stackoverflow.com/questions/48447149/typeerror-in-tensorflow-scipyoptimizerinterface-when-using-in-keras
model.compile(optimizer=TFOptimizer(ScipyOptimizerInterface()))