#Source: https://stackoverflow.com/questions/45000350/getting-attributeerror-during-instantiation-of-subclass
key = Keyword(["A", "B", "C", "D"])