#Source: https://stackoverflow.com/questions/48574871/pandas-typeerror-sequence-item-0-expected-str-instance-dict-found-when-using
int64 
object
float64