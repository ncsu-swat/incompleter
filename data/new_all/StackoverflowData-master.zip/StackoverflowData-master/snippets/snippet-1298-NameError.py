#Source: https://stackoverflow.com/questions/53812466/attributeerror-nonetype-object-has-no-attribute-lower-in-python
result_locality = model_locality.predict(locality_address)
print (result_locality)      