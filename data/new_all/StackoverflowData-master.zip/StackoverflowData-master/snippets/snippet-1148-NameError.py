#Source: https://stackoverflow.com/questions/52421840/bar-plot-with-color-gradient-on-each-bar-error-typeerror-object-of-type-list
color=plt.cm.get_cmap('bwr')