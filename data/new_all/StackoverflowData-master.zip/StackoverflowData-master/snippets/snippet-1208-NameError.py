#Source: https://stackoverflow.com/questions/34880923/python-3-error-typeerror-cant-convert-bytes-object-to-str-implicitly-in-str
all = str("At: " + date + " you have encrypted: " + text + " into:" + hex_dig)
text_file.write(together)