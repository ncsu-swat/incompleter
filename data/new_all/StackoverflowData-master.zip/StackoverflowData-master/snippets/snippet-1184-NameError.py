#Source: https://stackoverflow.com/questions/56090377/typeerror-keyword-argument-not-understood-module-when-loading-keras-sav
new_model=load_model("my_model.h5")
new_model.summary()