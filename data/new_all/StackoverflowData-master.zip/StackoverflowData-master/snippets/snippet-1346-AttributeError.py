#Source: https://stackoverflow.com/questions/23881783/twisted-typeerror-in-sendline
self.sendLine('%s %s RTSP/1.0' % (command, path))