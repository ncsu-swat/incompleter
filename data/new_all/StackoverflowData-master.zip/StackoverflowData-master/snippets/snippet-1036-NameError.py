#Source: https://stackoverflow.com/questions/51752140/one-line-string-iterator-attributeerror-generator-object-has-no-attribute-r
final_qry = (final_qry.replace(x, ' ') for x in clean_spaces)