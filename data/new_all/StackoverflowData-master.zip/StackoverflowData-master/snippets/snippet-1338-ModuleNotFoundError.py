#Source: https://stackoverflow.com/questions/38441889/get-nameerror-name-ip-is-not-defined-error-message
from scapy.all import *