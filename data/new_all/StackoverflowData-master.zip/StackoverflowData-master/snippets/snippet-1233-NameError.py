#Source: https://stackoverflow.com/questions/69302989/web-scraping-typeerror-nonetype-object-is-not-subscriptable-how-to
y = data[2].div.img['alt']
print(y)