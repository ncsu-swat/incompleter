#Source: https://stackoverflow.com/questions/49795022/nested-defaultdict-typeerror-first-argument-must-be-callable-or-none
dd = {str:{str:{str:{[]}}}}