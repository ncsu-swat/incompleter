#Source: https://stackoverflow.com/questions/34880923/python-3-error-typeerror-cant-convert-bytes-object-to-str-implicitly-in-str
date = time.strftime("%Y-%m-%d %H:%M:%S")