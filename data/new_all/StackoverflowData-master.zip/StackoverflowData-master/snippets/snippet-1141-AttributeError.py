#Source: https://stackoverflow.com/questions/56093978/need-help-understanding-why-i-get-attribute-error
motor_bikes = 'harley', 'Fz07', 'Crouch rocket'

last_owned = motor_bikes.pop()

print(last_owned)