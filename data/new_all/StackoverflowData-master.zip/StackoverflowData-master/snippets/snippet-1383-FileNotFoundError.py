#Source: https://stackoverflow.com/questions/67000739/slurm-job-nameerror-name-python3-is-not-defined
import pandas as pd
import numpy as np
true = pd.read_csv("testfile.csv")
print('Just Testing. End for now.')