#Source: https://stackoverflow.com/questions/75150732/typeerror-new-missing-1-required-positional-argument-task-while-runnin
data_dir = r"C:\Users\walte\Desktop\dataset\0111"
if __name__ == "__main__":
    main(data_dir)