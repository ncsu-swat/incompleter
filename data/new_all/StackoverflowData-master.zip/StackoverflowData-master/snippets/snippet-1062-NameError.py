#Source: https://stackoverflow.com/questions/47204175/lane-departure-warning-system-for-autonomous-driving-typeerror-expected-non-em
detector(binary_sub, ploty, visualization)