#Source: https://stackoverflow.com/questions/59014318/filenotfounderror-could-not-find-module-libvlc-dll
import vlc