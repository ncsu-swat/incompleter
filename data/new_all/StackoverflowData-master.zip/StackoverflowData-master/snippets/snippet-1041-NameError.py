#Source: https://stackoverflow.com/questions/23769732/python-pygame-colours-are-no-tuples-unhashable-type-error-when-used-as-dictiona
GRAY = (128, 128, 128, 255)

print(GRAY == clr)