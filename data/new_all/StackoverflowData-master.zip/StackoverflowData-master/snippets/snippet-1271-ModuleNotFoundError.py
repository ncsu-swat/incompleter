#Source: https://stackoverflow.com/questions/58878284/attribute-error-while-using-image-module-from-pil-library-in-python-3
from PIL import Image
from tkinter import *

root = Tk()

image2 = Image.open('hp png.png')

hp_image2 = Label(root , image = image2)

hp_image2.pack(fill = BOTH)

root.mainloop()