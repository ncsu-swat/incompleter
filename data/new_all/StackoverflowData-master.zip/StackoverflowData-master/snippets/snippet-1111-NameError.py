#Source: https://stackoverflow.com/questions/23424156/python-sort-with-key-lambda-gets-typeerror
db[count].sort(key=lambda a: a.data)