#Source: https://stackoverflow.com/questions/51660316/attributeerror-elementtree-object-has-no-attribute-tag-in-python
t = tostring(tree)