#Source: https://stackoverflow.com/questions/36896672/pascals-triangle-type-error
answer = answer + combination(row, column) + "\t"