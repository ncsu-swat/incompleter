#Source: https://stackoverflow.com/questions/45290161/attributeerror-module-object-has-no-attributes-extension-when-trying-to-use
import pandas as pd
import numpy as np
import holoviews as hv
hv.extension('bokeh')