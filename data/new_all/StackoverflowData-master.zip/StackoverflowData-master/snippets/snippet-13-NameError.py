#Source: https://stackoverflow.com/questions/57505071/nameerror-name-list-is-not-defined
def totalFruit(self, tree: List[int]) -> int:
    pass