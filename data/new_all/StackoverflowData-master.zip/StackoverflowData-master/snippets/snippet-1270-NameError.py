#Source: https://stackoverflow.com/questions/58878284/attribute-error-while-using-image-module-from-pil-library-in-python-3
image1 = Image.open('<file location>')