#Source: https://stackoverflow.com/questions/44946189/typeerror-init-got-an-unexpected-keyword-argument-shape
v = tf.get_variable("v", initializer=tf.zeros_initializer())