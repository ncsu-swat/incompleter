#Source: https://stackoverflow.com/questions/68346977/python-dictionary-typeerror-in-nested-dictionaries-using-datetime-as-a-key
sorted_result_devices = sorted(result_devices, reverse=True)