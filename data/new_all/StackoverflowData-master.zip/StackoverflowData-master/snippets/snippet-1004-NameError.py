#Source: https://stackoverflow.com/questions/57203454/why-does-python-raise-a-nameerror-for-conditional-list-comprehensions-inside-cla
class Foo:
    x = 5
    y = [x for i in range(1)]