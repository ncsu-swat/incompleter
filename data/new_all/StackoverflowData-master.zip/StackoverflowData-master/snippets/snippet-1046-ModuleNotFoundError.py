#Source: https://stackoverflow.com/questions/50261455/oop-name-error-while-trying-to-make-a-object-instance
import manage

FITobj= FIT()