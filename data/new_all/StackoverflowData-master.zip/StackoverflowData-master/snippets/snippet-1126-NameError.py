#Source: https://stackoverflow.com/questions/48772769/attributeerror-lower-not-found
doc_clf.predict(tf_idf.transform((count_vect.transform([r'document']))))