#Source: https://stackoverflow.com/questions/22596827/nameerror-name-random-is-not-defined
r = random.randint(1,10)