#Source: https://stackoverflow.com/questions/48528894/nameerror-name-functionname-is-not-defined
from UserInfo import UserInfo

user = UserInfo()
print(user.username)